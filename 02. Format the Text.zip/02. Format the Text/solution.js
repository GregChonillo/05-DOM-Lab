function solve() {
	let text = document.getElementById("input").innerText;
	let tempText = text.split(".");
	console.log(tempText.length);
	while (tempText.indexOf("") != -1) {
		tempText.splice(tempText.indexOf(""), 1);
	}
	console.log(tempText.length);
	for (let i = 0; i < Math.ceil(tempText.length / 3); i++) {
		let p = document.createElement("p");
		for (let j = i * 3; j < (i + 1) * 3 && j < tempText.length; j++) {
			p.innerText += tempText[j] + ".";
		}
		document.getElementById("output").append(p);
	}
	console.log(tempText);
}

solve();
